import os
import json
import requests
import google.generativeai as genai
from django.shortcuts import render

# Configure Gemini API once (ensure GEMINI_API_KEY is set in your environment)
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

# Define common generation configuration for Gemini
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

def analyze_sentiment_with_gemini(text):
    """
    Uses the Gemini GenerativeModel with system instruction "Sentiment"
    to analyze the sentiment of the provided text.
    """
    model = genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        generation_config=generation_config,
        system_instruction="Examine the following text and determine its overall sentiment. Based solely on the tone and context, respond with exactly one word: 'positive', 'negative', or 'neutral'. Do not include any additional commentary, punctuation, or formatting.",
    )
    chat_session = model.start_chat(history=[])
    response = chat_session.send_message(text)
    return response.text.strip()

def home(request):
    # Get the search query from GET parameter "q", defaulting to a specific college name.
    query = request.GET.get("q", "Rungta College Of Engineering and Technology Bhilai")
    
    # Retrieve your NewsAPI key from the environment variable.
    newsapi_key = os.getenv("NEWSAPI_API_KEY")
    if not newsapi_key:
        raise Exception("Please set the NEWSAPI_API_KEY environment variable.")
    
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": query,
        "apiKey": newsapi_key,
        "language": "en",
        "sortBy": "publishedAt",
        "pageSize": 10,  # Limit results to 10 articles
    }
    
    response = requests.get(url, params=params)
    articles = []
    if response.status_code == 200:
        data = response.json()
        articles = data.get("articles", [])
        # For each article, combine title and description and analyze sentiment using Gemini.
        for article in articles:
            combined_text = f"Title: {article.get('title', '')}\nDescription: {article.get('description', '')}"
            article["sentiment"] = analyze_sentiment_with_gemini(combined_text)
    else:
        print("Error fetching articles:", response.status_code, response.text)
    
    # Compute sentiment counts for the pie chart.
    sentiment_counts = {"positive": 0, "negative": 0, "neutral": 0}
    for article in articles:
        sentiment = article.get("sentiment", "neutral").lower()
        if sentiment in sentiment_counts:
            sentiment_counts[sentiment] += 1
        else:
            sentiment_counts["neutral"] += 1

    context = {
        "articles": articles,
        "query": query,
        # Pass sentiment counts as a JSON string to safely embed in the template
        "sentiment_counts": json.dumps(sentiment_counts)
    }
    
    return render(request, "fetcher/index.html", context)
